﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.Collections.Generic;

    [Serializable]
    public class Appointment
    {
        public string CustomerId { get; set; }

        public string AppointmentId { get; set; }

        public string Purpose { get; set; }

        public string Address { get; set; }

        public string AppointmentDate { get;  set; }

        public string Status { get; set; }
        
    }
}