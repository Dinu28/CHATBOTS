﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class AppointmentQuery
    {
        [Required]
        public string Address { get; set; }

        [Required]
        public string Purpose { get; set; }

        [Required]
        public DateTime? AppointmentDate { get; set; }

        public string CustomerID { get; set; }


        public static AppointmentQuery Parse(dynamic o)
        {
            try
            {
                return new AppointmentQuery
                {
                    Address = o.Address.ToString(),
                    AppointmentDate = DateTime.Parse(o.AppointmentDate.ToString()),
                    Purpose = o.Purpose.ToString(),
                    CustomerID = o.CustomerID.ToString()
                };
            }
            catch
            {
                throw new InvalidCastException("HotelQuery could not be read");
            }
        }
    }
}