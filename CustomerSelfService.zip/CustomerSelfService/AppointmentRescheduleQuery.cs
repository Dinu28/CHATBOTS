﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class AppointmentRescheduleQuery
    {
        [Required]
        public DateTime? RescueduleDate { get; set; }

        public string AppointmentID { get; set; }
  
        public string CustomerID { get; set; }


        public static AppointmentRescheduleQuery Parse(dynamic o)
        {
            DateTime localDateTime;
            try
            {
                localDateTime = DateTime.Parse(o.RescueduleDate.ToString());
                return new AppointmentRescheduleQuery
                {
                    RescueduleDate = localDateTime.Date.ToLocalTime(),
                    AppointmentID = o.AppointmentID.ToString(),
                    CustomerID = o.CustomerID.ToString()
                };
            }
            catch
            {
                throw new InvalidCastException("AppointmentRescheduleQuery could not be read");
            }
        }
    }
}