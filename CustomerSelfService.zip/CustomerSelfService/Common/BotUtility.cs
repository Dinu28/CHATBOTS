﻿using AdaptiveCards;
using BotBuilder.Samples.AdaptiveCards.Dynamics;
using Microsoft.Bot.Builder.Dialogs;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace BotBuilder.Samples.AdaptiveCards.Common
{
    public static class BotUtility
    {
        public static AdaptiveCard ShowOptions()
        {
            AdaptiveCard card = new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                    new Container()
                    {
                        Speak = "<s>Hello!</s><s>Welcome to Lowe's Customer Self Service</s>",
                        Items = new List<CardElement>()
                        {
                            new ColumnSet()
                            {
                                Columns = new List<Column>()
                                {
                                    new Column()
                                    {
                                        Size = ColumnSize.Stretch,
                                        Items = new List<CardElement>()
                                        {
                                            new TextBlock()
                                            {
                                                Text =  "Hello!",
                                                Weight = TextWeight.Bolder,
                                                IsSubtle = true
                                            },
                                            new TextBlock()
                                            {
                                                Text = "Welcome to Lowe's Customer Self Service",
                                                Wrap = true
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                // Buttons
                Actions = new List<ActionBase>() {
                    new ShowCardAction()
                    {
                        Title = "Sign In",
                        Speak = "<s>Sign In</s>",
                        Card = FetchCustomerDetails()
                    },
                    new ShowCardAction()
                    {
                        Title = "Sign Up",
                        Speak = "<s>Sign Up</s>",
                        Card = RegisterCustomer()
                    }
                }
            };
            return card;
        }
        private static AdaptiveCard FetchCustomerDetails()
        {
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                        // Hotels Search form
                        new TextBlock()
                        {
                            Text = "Sign In !",
                            Speak = "<s>Sign In</s>",
                            Weight = TextWeight.Bolder,
                            Size = TextSize.Large
                        },
                        new TextBlock() { Text = "Customer ID" },
                        new TextInput()
                        {
                            Id = "CustomerId",
                            Speak = "<s>Customer ID</s>",
                            Placeholder = "Customer ID",
                            Style = TextInputStyle.Text
                        }
                },
                Actions = new List<ActionBase>()
                {
                    new SubmitAction()
                    {
                        Title = "Sign In",
                        Speak = "<s>Sign In</s>",
                        DataJson = "{ \"Type\": \"CustomerSignIn\" }"
                    }
                }
            };
        }        
        public static AdaptiveCard RegisterCustomer()
        {
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                        // Hotels Search form
                        new TextBlock()
                        {
                            Text = "Please enter your details !",
                            Speak = "<s>Please enter your details</s>",
                            Weight = TextWeight.Bolder,
                            Size = TextSize.Large
                        },
                        new TextBlock() { Text = "Please enter your First Name" },
                        new TextInput()
                        {
                            Id = "FirstName",
                            Speak = "<s>Please enter your First Name</s>",
                            Placeholder = "",
                            Style = TextInputStyle.Text
                        },
                        new TextBlock() { Text = "Please enter your Last Name" },
                        new TextInput()
                        {
                            Id = "LastName",
                            Speak = "<s>Please enter your Last Name</s>",
                            Placeholder = "",
                            Style = TextInputStyle.Text
                        },
                        new TextBlock() { Text = "Please provide your Phone Number?" },
                        new TextInput()
                        {
                            Id = "Phone",
                            Speak = "<s>Please provide your Phone Number</s>",
                            Style = TextInputStyle.Text
                        },
                        new TextBlock() { Text = "Please provide your Email" },
                        new TextInput()
                        {
                            Id = "Email",
                            Speak = "<s>Please enter your Email</s>",
                            Placeholder = "address@email.com",
                            Style = TextInputStyle.Text
                        },
                },
                Actions = new List<ActionBase>()
                {
                    new SubmitAction()
                    {
                        Title = "Register",
                        Speak = "<s>Register</s>",
                        DataJson = "{ \"Type\": \"CustomerSignUp\" }"
                    }
                }
            };
        }
        public static AdaptiveCard SendAppointmentSelection(Appointment appointment)
        {
            var description = $"{appointment.Purpose}";
            var card = new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                    new Container()
                    {
                        Items = new List<CardElement>()
                        {
                            new TextBlock()
                            {
                                Text = $"{appointment.AppointmentId}",
                                Weight = TextWeight.Bolder,
                                Speak = $"<s>{appointment.AppointmentId}</s>",
                                 Size = TextSize.Medium,
                                Color=TextColor.Attention,
                                IsSubtle = true
                            },
                            new TextBlock()
                            {
                                Text = description,
                                 Speak = $"<s>{description}</s>",
                                 Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Dark,
                                IsSubtle = true
                            },
                            new TextBlock()
                            {
                                Text = $"{appointment.AppointmentDate}",
                                Speak = $"<s>{appointment.AppointmentDate}</s>",
                                 Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Dark,
                                IsSubtle = true
                            }
                        }
                    }
                },
                Actions = new List<ActionBase>() {
                    new SubmitAction()
                    {
                        Title = "Cancle Appointment",
                        Speak = "<s>Cancle Appointment</s>",
                        DataJson = "{ \"Type\": \"CancelAppointment\",\"AppointmentID\": \"" + appointment.AppointmentId + "\" }"
                    },
                     new ShowCardAction()
                    {
                        Title = "Reschedule Appointment",
                        Speak = "<s>Reschedule Appointment</s>",
                        Card = RescheduleAppointment( appointment.AppointmentId, appointment.CustomerId)
                    }
                }
            };
            return card;
        }
        private static AdaptiveCard RescheduleAppointment(string AppointmentId, string customerId)
        {
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                        // Hotels Search form
                        new TextBlock()
                        {
                            Text = "Reschedule Appointment: "+ AppointmentId,
                            Weight = TextWeight.Bolder,
                            Size = TextSize.Large
                        },
                           // Hotels Search form
                        new TextBlock() { Text = "Reschedule To Date" },
                        new DateInput()
                        {
                            Id = "RescueduleDate",
                            Placeholder = "mm/dd/yyyy"
                        }

                },
                Actions = new List<ActionBase>()
                {
                    new SubmitAction()
                    {
                        Title = "Reschedule",
                        Speak = "<s>Reschedule</s>",
                        DataJson = "{ \"Type\": \"RescheduleAppointment\",\"AppointmentID\": \"" + AppointmentId + "\",\"CustomerID\": \"" + customerId + "\"}"
                    }
                }
            };
        }
        public static AdaptiveCard GetCustomerOrders(string customerId)
        {
            CustomerRepository CusRepo = new CustomerRepository();
            var appointments =  CusRepo.GetJobDetails(Int32.Parse(customerId));

            var intro = new List<CardElement>()
            {
                    new TextBlock()
                    {
                        Text = "Your Appointments",
                        Speak = "<s>Your Appointments</s>",
                        Weight = TextWeight.Bolder,
                        Size = TextSize.Large
                    }
            };

            var card = new AdaptiveCard()
            {
                Body = intro
            };

            foreach (var appointment in appointments)
            {
                card.Body.Add(AsHotelItem(appointment));
            }
            return card;

        }
        private static new ColumnSet AsHotelItem(Appointment appointment)
        {
            var submitActionData = JObject.Parse("{ \"Type\": \"AppointmentSelection\" }");
            submitActionData.Merge(JObject.FromObject(appointment));

            var colDataSet = new ColumnSet();
            colDataSet.Separation = SeparationStyle.Strong;
            List<Column> colList = new List<Column>();
            colList.Add(
                new Column()
                {
                    Items = new List<CardElement>()
                    {
                         new TextBlock()
                            {
                                Text = appointment.AppointmentId,
                                Weight = TextWeight.Bolder,
                                Size = TextSize.Medium,
                                Color=TextColor.Attention,
                                IsSubtle = true
                            },
                         new TextBlock()
                            {
                                Text = appointment.Purpose,
                                Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Dark,
                                IsSubtle = true
                            },
                        new TextBlock()
                            {
                                Text = appointment.AppointmentDate,
                                Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Dark,
                                IsSubtle = true
                            },
                        new TextBlock()
                            {
                                Text = appointment.Status,
                                Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Attention,
                                IsSubtle = true
                            }
                    },
                    SelectAction = new SubmitAction()
                    {
                        DataJson = submitActionData.ToString()
                    }
                });
            colDataSet.Columns = colList;
            return colDataSet;
        }
        public static AdaptiveCard AppointmentSelection(AppointmentRescheduleQuery appointment)
        {
            var description = $"this appointment got rescheduled to";
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                    new Container()
                    {
                        Items = new List<CardElement>()
                        {
                            new TextBlock()
                            {
                                Text = $"{appointment.AppointmentID}",
                                Weight = TextWeight.Bolder,
                                Speak = $"<s>{appointment.AppointmentID}</s>",
                                 Size = TextSize.Medium,
                                Color=TextColor.Attention,
                                IsSubtle = true
                            },
                            new TextBlock()
                            {
                                Text = description,
                                Speak = $"<s>{description}</s>",
                                 Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Dark,
                                IsSubtle = true
                            },
                            new TextBlock()
                            {
                                Text = $"{appointment.RescueduleDate}",
                                Speak = $"<s>{appointment.RescueduleDate}</s>",
                                 Weight = TextWeight.Normal,
                                Size = TextSize.Small,
                                Color=TextColor.Dark,
                                IsSubtle = true
                            }
                        }
                    }
                }
            };
        }

        


        public static AdaptiveCard CustomerDetailViewer(Customer cust)
        {
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                    new TextBlock()
                    {
                        Text = "Customer ID: " + cust.CustomerId,
                        Size = TextSize.ExtraLarge,
                        Speak = $"<s>Customer ID: {cust.CustomerId}</s>"
                    },
                    new TextBlock()
                    {
                        Text = cust.FirstName + " " + cust.LastName,
                        Speak = $"<s>{cust.FirstName} {cust.LastName}</s>",
                        HorizontalAlignment = HorizontalAlignment.Left,
                        Wrap = false,
                        Weight = TextWeight.Bolder
                    }
                },
                Actions = new List<ActionBase>() {
                    new ShowCardAction()
                    {
                        Title = "Book Appointment",
                        Speak = "<s>Book Appointment</s>",
                        Card = BookAppointment(cust.CustomerId)
                    },
                     new ShowCardAction()
                    {
                        Title = "Your Appointments",
                        Speak = "<s>Your Appointments</s>",
                        Card = GetCustomerOrders(cust.CustomerId)
                    },
                }
            };
        }
        public static AdaptiveCard BookAppointment(string customerId)
        {
            return new AdaptiveCard()
            {
                Body = new List<CardElement>()
                {
                        // Hotels Search form
                        new TextBlock()
                        {
                            Text = "Book an Appointment",
                            Speak = "<s>Book an Appointment</s>",
                            Weight = TextWeight.Bolder,
                            Size = TextSize.Large
                        },
                        new TextBlock() { Text = "Purpose of Appointment" },
                        new TextInput()
                        {
                            Id = "Purpose",
                            Speak = "<s>Purpose of Appointment</s>",
                            Placeholder = "",
                            Style = TextInputStyle.Text
                        },
                        new TextBlock() { Text = "Please enter Address" },
                        new TextInput()
                        {
                            Id = "Address",
                            Speak = "<s>Please enter Address</s>",
                            Placeholder = "",
                            Style = TextInputStyle.Text
                        },
                        new TextBlock() { Text = "Please set your Appointment Date" },
                        new DateInput()
                        {
                            Id = "AppointmentDate",
                            Speak = "<s>Please set your Appointment Date</s>",
                            IsRequired = true
                        }
                },
                Actions = new List<ActionBase>()
                {
                    new SubmitAction()
                    {
                        Title = "Book",
                        Speak = "<s>Book</s>",
                        DataJson = "{ \"Type\": \"BookAppointment\",\"CustomerID\": \"" + customerId + "\" }"
                    }
                }
            };
        }
    }
}