﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.Collections.Generic;

    [Serializable]
    public class Customer
    {
        public string CustomerId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Phone { get;  set; }
        
        public string Image { get;  set; }
    }

    public static class CustomerInfo
    {
        public static string CustomerId { get; set; } = string.Empty;

        public static string FName { get; set; }
        
    }
}