﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class CustomerQuery
    {
        [Required]
        public string FirstName { get; set; }
        
        [Required]
        public string LastName { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public string Phone { get; set; }

        public static CustomerQuery Parse(dynamic o)
        {
            try
            {
                return new CustomerQuery
                {
                    FirstName = o.FirstName.ToString(),
                    LastName = o.LastName.ToString(),
                    Email = o.Email.ToString(),
                    Phone = o.Phone.ToString()
                };
            }
            catch
            {
                throw new InvalidCastException("CustomerQuery could not be read");
            }
        }
    }
}