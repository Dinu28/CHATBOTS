﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using global::AdaptiveCards;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Builder.FormFlow;
    using Microsoft.Bot.Connector;
    using Newtonsoft.Json.Linq;
    using BotBuilder.Samples.AdaptiveCards.Dynamics;
    using BotBuilder.Samples.AdaptiveCards.Common;

    [Serializable]
    public class AppointmentDialog : IDialog<object>
    {
        public async Task StartAsync(IDialogContext context)
        {
            var message = context.Activity as IMessageActivity;
            var appointmentDetails = AppointmentQuery.Parse(message.Value);
            try
            {
                CustomerRepository CusRepo = new CustomerRepository();
                await context.PostAsync($"Please be with us while we get your appointments.");
                string result = CusRepo.CreateAppointment(appointmentDetails);

                await context.PostAsync($"Appointment has been created succesfully.");
                //await CreateAppointment(context, customerDetails);
                AdaptiveCard card = BotUtility.GetCustomerOrders(appointmentDetails.CustomerID);
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };
                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);
                await context.PostAsync(reply);
            }
            catch (FormCanceledException ex)
            {
                await context.PostAsync($"Oops! Something went wrong :( Technical Details: {ex.InnerException.Message}");
            }
        }
        
    }
}