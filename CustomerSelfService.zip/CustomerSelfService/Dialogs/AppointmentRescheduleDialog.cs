﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using global::AdaptiveCards;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Builder.FormFlow;
    using Microsoft.Bot.Connector;
    using Newtonsoft.Json.Linq;
    using BotBuilder.Samples.AdaptiveCards.Dynamics;
    using Newtonsoft.Json;
    using System.Threading;
    using BotBuilder.Samples.AdaptiveCards.Common;

    [Serializable]
    public class AppointmentRescheduleDialog : IDialog<object>
    {
        public async Task StartAsync(IDialogContext context)
        {
            var message = context.Activity as IMessageActivity;
            var appointmentDetails = AppointmentRescheduleQuery.Parse(message.Value);
            try
            {
                CustomerRepository CusRepo = new CustomerRepository();
                await context.PostAsync($"We are rescheduling your appointment...");
                if (CusRepo.RescheduleAppointments(appointmentDetails))
                {
                    await context.PostAsync($"Appointment has been rescheduled succesfully...");
                    await SendAppointmentSelectionAsync(context, appointmentDetails);
                }
                else
                {
                    await context.PostAsync("Unable to reschedule appointment, Our representative will contact you.");
                }

            }
            catch (FormCanceledException ex)
            {
                await context.PostAsync($"Oops! Something went wrong :( Technical Details: {ex.InnerException.Message}");
            }
        }        
        private static async Task SendAppointmentSelectionAsync(IDialogContext context, AppointmentRescheduleQuery appointment)
        {
            AdaptiveCard card = BotUtility.AppointmentSelection(appointment);

            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            var reply = context.MakeMessage();
            reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);
        }      

    }
}