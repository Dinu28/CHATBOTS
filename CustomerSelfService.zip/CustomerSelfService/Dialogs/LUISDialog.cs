﻿using AdaptiveCards;
using BotBuilder.Samples.AdaptiveCards.Common;
using BotBuilder.Samples.AdaptiveCards.Dynamics;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace BotBuilder.Samples.AdaptiveCards
{
    
    //[LuisModel("4bfcc15a-8910-4631-8b43-37bb57cad560", "5f389cf2ce874576b30dac522752d61e")] //Subbu's
    //[LuisModel("b8aec601-93bc-4db7-acad-7c51f5fa8a72", "07016855de7e44519bbe32161281da3d")] //Vidhya's

    [LuisModel("58e217e8-58d2-40eb-b0a9-1019a41c2a47", "d597fc084b494912a5e1bf62a6874382")]
    [Serializable]
    public class LUISDialog : LuisDialog<object>
    {
        
        [LuisIntent("")]
        public async Task None(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Sorry I dont understand");
            context.Wait(MessageReceived);
        }

        [LuisIntent("greetings")]
        public async Task greetings(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Hi, Please let me know how can i help you?");
            context.Wait(MessageReceived);
        }

        [LuisIntent("registeredcustomer")]
        public async Task registeredcustomer(IDialogContext context, LuisResult result)
        {
            await context.PostAsync($"Please be with us while we get your appointments.");
            AdaptiveCard card = BotUtility.GetCustomerOrders(result.Query);
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            var reply = context.MakeMessage();
            reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);

            CustomerInfo.CustomerId = result.Query;

            context.Wait(MessageReceived);
        }

        [LuisIntent("bookappointment")]
        public async Task bookappointment(IDialogContext context, LuisResult result)
        {
            string customerId = string.Empty;
            if (CustomerInfo.CustomerId != null && !CustomerInfo.CustomerId.Equals(string.Empty) && CustomerInfo.CustomerId.Length > 0)
            {
                customerId = CustomerInfo.CustomerId;
            }
            if (customerId.Equals(String.Empty))
            {
                await context.PostAsync("Provide your CustomerID if you know");
            }
            else
            {
                AdaptiveCard card = BotUtility.BookAppointment(customerId);
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);

                await context.PostAsync(reply, CancellationToken.None);
            }
            context.Wait(MessageReceived);
        }

        [LuisIntent("nonregisteredcustomer")]
        public async Task nonregisteredcustomer(IDialogContext context, LuisResult result)
        {
                
                AdaptiveCard card = BotUtility.RegisterCustomer();
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);
            context.Wait(MessageReceived);
        }

        [LuisIntent("Interest")]
        public async Task Interest(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Interest");
            context.Wait(MessageReceived);
        }

        [LuisIntent("knowmyappointments")]
        public async Task knowmyappointments(IDialogContext context, LuisResult result)
        {
            string customerId = string.Empty;
            if (CustomerInfo.CustomerId != null && !CustomerInfo.CustomerId.Equals(string.Empty) && CustomerInfo.CustomerId.Length > 0)
            {
                customerId = CustomerInfo.CustomerId;
            }
            if (customerId.Equals(String.Empty))
            {
                await context.PostAsync("Provide your CustomerID if you know");
            }
            else
            {
                await context.PostAsync($"Please be with us while we get your appointments.");
                AdaptiveCard card = BotUtility.GetCustomerOrders(customerId);
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };

                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);

                await context.PostAsync(reply, CancellationToken.None);
            }
            context.Wait(MessageReceived);
        }

        [LuisIntent("arrangecallBack")]
        public async Task arrangecallBack(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Our Customer Representative will call you back and provide required assistance.");
            context.Wait(MessageReceived);
        }
        
        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(this.MessageReceived);
        }

        public virtual async Task MessageReceived(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            if (message.Value != null)
            {
                // Got an Action Submit
                dynamic value = message.Value;
                string submitType = value.Type.ToString();
                switch (submitType)
                {
                    case "CustomerSignIn":
                        RegisteredCustomerQuery query;
                        try
                        {
                            query = RegisteredCustomerQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(query, new ValidationContext(query, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        CustomerInfo.CustomerId = query.CustomerId;
                        // Proceed with hotels search
                        await context.Forward(new RegisteredCustomerDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);

                        return;
                    case "CustomerSignUp":
                            CustomerQuery suQuery;
                            try
                            {
                                suQuery = CustomerQuery.Parse(value);

                                // Trigger validation using Data Annotations attributes from the HotelsQuery model
                                List<ValidationResult> results = new List<ValidationResult>();
                                bool valid = Validator.TryValidateObject(suQuery, new ValidationContext(suQuery, null, null), results, true);
                                if (!valid)
                                {
                                    // Some field in the Hotel Query are not valid
                                    var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                    await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                    return;
                                }
                            }
                            catch (InvalidCastException)
                            {
                                // Hotel Query could not be parsed
                                await context.PostAsync("Please complete all the search parameters");
                                return;
                            }
                            // Proceed with hotels search
                            await context.Forward(new CustomerSelfServiceDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);
                        return;

                    case "BookAppointment":
                        AppointmentQuery aQuery;
                        try
                        {
                            aQuery = AppointmentQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(aQuery, new ValidationContext(aQuery, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        // Proceed with hotels search
                        await context.Forward(new AppointmentDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);
                        return;

                    case "AppointmentSelection":
                        await SendAppointmentSelectionAsync(context, (Appointment)JsonConvert.DeserializeObject<Appointment>(value.ToString()));
                        context.Wait(MessageReceived);

                        return;
                    case "CancelAppointment":
                        await CancelAppointmentAsync(context, (Appointment)JsonConvert.DeserializeObject<Appointment>(value.ToString()));
                        context.Wait(MessageReceived);
                        return;
                    case "RescheduleAppointment":
                        AppointmentRescheduleQuery arQuery;
                        try
                        {
                            arQuery = AppointmentRescheduleQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(arQuery, new ValidationContext(arQuery, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        // Proceed with hotels search
                        await context.Forward(new AppointmentRescheduleDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);
                        break;
                }
            }

            if (message.Text != null && (message.Text.ToLower().Contains("help") || message.Text.ToLower().Contains("support") || message.Text.ToLower().Contains("problem")))
            {
                await context.Forward(new SupportDialog(), this.ResumeAfterSupportDialog, message, CancellationToken.None);
            }
            else
            {
                await context.Forward(new LUISDialog(), this.ResumeAfterLUIStDialog, message, CancellationToken.None);
            }
        }

        private async Task ResumeAfterLUIStDialog(IDialogContext context, IAwaitable<object> result)
        {
            var ticketNumber = await result;

            await context.PostAsync($"Thanks for contacting our support team. Your ticket number is {ticketNumber}.");
            context.Wait(this.MessageReceived);
        }

        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Wait(this.MessageReceived);
        }

        private async Task ResumeAfterSupportDialog(IDialogContext context, IAwaitable<int> result)
        {
            var ticketNumber = await result;

            await context.PostAsync($"Thanks for contacting our support team. Your ticket number is {ticketNumber}.");
            context.Wait(this.MessageReceived);
        }
        
        private static async Task SendAppointmentSelectionAsync(IDialogContext context, Appointment appointment)
        {
            AdaptiveCard card = BotUtility.SendAppointmentSelection(appointment);
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };
            var reply = context.MakeMessage();
            reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);
        }
        private static async Task CancelAppointmentAsync(IDialogContext context, Appointment appointment)
        {
            CustomerRepository cr = new CustomerRepository();
            var isCanceled = cr.CancelAppointments(Int32.Parse(appointment.AppointmentId));
            if (isCanceled == true)
                await context.PostAsync("Appointment has been canceled");
            else
                await context.PostAsync("Unable to cancel appointment, Our representative will contact you.");
        }

    }
}