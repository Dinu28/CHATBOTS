﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using global::AdaptiveCards;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Builder.FormFlow;
    using Microsoft.Bot.Connector;
    using Newtonsoft.Json.Linq;
    using BotBuilder.Samples.AdaptiveCards.Dynamics;
    using BotBuilder.Samples.AdaptiveCards.Common;

    [Serializable]
    public class RegisteredCustomerDialog : IDialog<object>
    {
        public async Task StartAsync(IDialogContext context)
        {
            var message = context.Activity as IMessageActivity;
            var customerDetails = RegisteredCustomerQuery.Parse(message.Value);            
            try
            {
                await GetCustomerDetails(context, customerDetails);
            }
            catch (FormCanceledException ex)
            {
                await context.PostAsync($"Oops! Something went wrong :( Technical Details: {ex.InnerException.Message}");
            }
        }        
        private async Task GetCustomerDetails(IDialogContext context, RegisteredCustomerQuery searchQuery)
        {
            CustomerRepository CusRepo = new CustomerRepository();
            Customer cust = new Customer();
            await context.PostAsync($"We are fetching your details. Please wait...");
            cust = CusRepo.GetCustomerDetailsInDynamics(searchQuery);
            
            if (cust.CustomerId == null)
                await context.PostAsync($"We are unable to find your detials. Please check your Customer ID.");
            else
            {
                AdaptiveCard card = BotUtility.CustomerDetailViewer(cust);
                Attachment attachment = new Attachment()
                {
                    ContentType = AdaptiveCard.ContentType,
                    Content = card
                };
                var reply = context.MakeMessage();
                reply.Attachments.Add(attachment);
                //reply.Attachments.Add(heroCard.ToAttachment());
                await context.PostAsync(reply);
            }
        }
    }
}