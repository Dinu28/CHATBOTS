﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using BotBuilder.Samples.AdaptiveCards.Common;
    using BotBuilder.Samples.AdaptiveCards.Dynamics;
    using global::AdaptiveCards;
    using Microsoft.Bot.Builder.Dialogs;
    using Microsoft.Bot.Connector;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public async Task StartAsync(IDialogContext context)
        {
            context.Wait(this.MessageReceivedAsync);
        }

        public virtual async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            var message = await result;

            if (message.Value != null)
            {
                // Got an Action Submit
                dynamic value = message.Value;
                string submitType = value.Type.ToString();
                switch (submitType)
                {
                    case "CustomerSignIn":
                        RegisteredCustomerQuery query;
                        try
                        {
                            query = RegisteredCustomerQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(query, new ValidationContext(query, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        context.UserData.SetValue<string>("CustomerID", query.CustomerId);
                        // Proceed with hotels search
                        await context.Forward(new RegisteredCustomerDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);

                        return;
                    case "CustomerSignUp":
                        CustomerQuery suQuery;
                        try
                        {
                            suQuery = CustomerQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(suQuery, new ValidationContext(suQuery, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        // Proceed with hotels search
                        await context.Forward(new CustomerSelfServiceDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);

                        return;

                    case "BookAppointment":
                        AppointmentQuery aQuery;
                        try
                        {
                            aQuery = AppointmentQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(aQuery, new ValidationContext(aQuery, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        // Proceed with hotels search
                        await context.Forward(new AppointmentDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);

                        return;
                    case "AppointmentSelection":
                        await SendAppointmentSelectionAsync(context, (Appointment)JsonConvert.DeserializeObject<Appointment>(value.ToString()));
                        context.Wait(MessageReceivedAsync);
                        
                        return;
                    case "CancelAppointment":
                        await SendAppointmentSelectionAsync(context, (Appointment)JsonConvert.DeserializeObject<Appointment>(value.ToString()));
                        context.Wait(MessageReceivedAsync);
                        return;
                    case "RescheduleAppointment":
                        AppointmentRescheduleQuery arQuery;
                        try
                        {
                            arQuery = AppointmentRescheduleQuery.Parse(value);

                            // Trigger validation using Data Annotations attributes from the HotelsQuery model
                            List<ValidationResult> results = new List<ValidationResult>();
                            bool valid = Validator.TryValidateObject(arQuery, new ValidationContext(arQuery, null, null), results, true);
                            if (!valid)
                            {
                                // Some field in the Hotel Query are not valid
                                var errors = string.Join("\n", results.Select(o => " - " + o.ErrorMessage));
                                await context.PostAsync("Please complete all the search parameters:\n" + errors);
                                return;
                            }
                        }
                        catch (InvalidCastException)
                        {
                            // Hotel Query could not be parsed
                            await context.PostAsync("Please complete all the search parameters");
                            return;
                        }
                        // Proceed with hotels search
                        await context.Forward(new AppointmentRescheduleDialog(), this.ResumeAfterOptionDialog, message, CancellationToken.None);
                        break;
                }
            }

            if (message.Text != null && (message.Text.ToLower().Contains("help") || message.Text.ToLower().Contains("support") || message.Text.ToLower().Contains("problem")))
            {
                await context.Forward(new SupportDialog(), this.ResumeAfterSupportDialog, message, CancellationToken.None);
            }
            else
            {
                await context.Forward(new LUISDialog(), this.ResumeAfterLUIStDialog, message, CancellationToken.None);
            }
        }

        private async Task ResumeAfterLUIStDialog(IDialogContext context, IAwaitable<object> result)
        {
            var ticketNumber = await result;

            await context.PostAsync($"Thanks for contacting our support team. Your ticket number is {ticketNumber}.");
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task ShowOptionsAsync(IDialogContext context)
        {
            AdaptiveCard card = BotUtility.ShowOptions();
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };

            var reply = context.MakeMessage();
            reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);

            context.Wait(MessageReceivedAsync);
        }

        private async Task ResumeAfterOptionDialog(IDialogContext context, IAwaitable<object> result)
        {
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task ResumeAfterSupportDialog(IDialogContext context, IAwaitable<int> result)
        {
            var ticketNumber = await result;

            await context.PostAsync($"Thanks for contacting our support team. Your ticket number is {ticketNumber}.");
            context.Wait(this.MessageReceivedAsync);
        }


        private static async Task SendAppointmentSelectionAsync(IDialogContext context, Appointment appointment)
        {
            AdaptiveCard card = BotUtility.SendAppointmentSelection(appointment);
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };
            var reply = context.MakeMessage();
            reply.Attachments.Add(attachment);

            await context.PostAsync(reply, CancellationToken.None);
        }
        private static async Task CancelAppointmentAsync(IDialogContext context, Appointment appointment)
        {
            CustomerRepository cr = new CustomerRepository();
            var isCanceled = cr.CancelAppointments(Int32.Parse(appointment.AppointmentId));
            if (isCanceled == true)
                await context.PostAsync("Appointment has been canceled");
            else
                await context.PostAsync("Unable to cancel appointment, Our representative will contact you.");
        }


    }
}