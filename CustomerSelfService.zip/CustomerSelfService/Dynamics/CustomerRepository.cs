﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using BotBuilder.Samples.AdaptiveCards.Models;

namespace BotBuilder.Samples.AdaptiveCards.Dynamics
{
    public class CustomerRepository
    {
        public Customer GetCustomerDetailsInDynamics(RegisteredCustomerQuery searchQuery)
        {
            Customer cust = new Customer();

            string url = "http://customerservicsapi20170919111831.azurewebsites.net/api/contact?id=" + int.Parse(searchQuery.CustomerId);
            HttpWebRequest webreq = (HttpWebRequest)WebRequest.Create(url);
            webreq.ContentType = "application/json";
            //webreq.Accept = "text/xml";
            webreq.Headers.Clear();
            webreq.Method = "GET";
            Encoding encode = Encoding.GetEncoding("utf-8");
            HttpWebResponse webres = null;
            webres = (HttpWebResponse)webreq.GetResponse();
            Stream reader = null;
            reader = webres.GetResponseStream();
            StreamReader sreader = new StreamReader(reader, encode, true);
            string resultresponse = sreader.ReadToEnd();
            CustomerModel custmodel = JsonConvert.DeserializeObject<CustomerModel>(resultresponse);

            if (custmodel != null)
            {
                cust.CustomerId = custmodel.ContactNumber.ToString();
                cust.Email = custmodel.EMailAddress1;
                cust.FirstName = custmodel.FirstName;
                cust.LastName = custmodel.LastName;
                cust.Phone = custmodel.Telephone1.ToString();
                cust.Image = @"C:\Subbu\Git\BotBuilder-Samples\CSharp\cards-AdaptiveCards\images\bot_icon.png";
            }

            return cust;
        }

        public Customer CreateCustomerInDynamics(CustomerQuery searchQuery)
        {
            Customer cust = new Customer();
            string resultresponse = string.Empty;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://customerservicsapi20170919111831.azurewebsites.net/api/contact");
            httpWebRequest.Method = "POST";
            // httpWebRequest.Headers.Add("aftership-api-key:********fdbfd93980b8c5***");
            httpWebRequest.ContentType = "application/json";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string postData = "{\"eMailAddress1\": \"" + searchQuery.Email + "\","
                                    + "\"firstName\": \"" + searchQuery.FirstName + "\","
                                    + "\"lastName\": \"" + searchQuery.LastName + "\","
                                    + "\"telephone1\": " + searchQuery.Phone + ""
                                    + "}";

                //string postData = "{\"contactnumber\": 12345,\"secretQuestion\": \"What is your favorite pet\",\"secretAnswer\": \"pupp\"}";
                streamWriter.Write(postData);
                streamWriter.Flush();
                streamWriter.Close();

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    resultresponse = streamReader.ReadToEnd();
                }
            }
            if (resultresponse != string.Empty)
            {
                string[] arr = resultresponse.Split(':');
                if (arr[0] == "true")
                {
                    cust.CustomerId = arr[1].ToString();
                    cust.Email = searchQuery.Email;
                    cust.FirstName = searchQuery.FirstName;
                    cust.LastName = searchQuery.LastName;
                    cust.Phone = searchQuery.Phone;
                    cust.Image = @"C:\Subbu\Git\BotBuilder-Samples\CSharp\cards-AdaptiveCards\images\bot_icon.png";
                }

            }

            return cust;
        }

        public string CreateAppointment(AppointmentQuery Query)
        {
            string result = "fail";


            string resultresponse = string.Empty;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://customerservicsapi20170919111831.azurewebsites.net/api/detail");
            httpWebRequest.Method = "POST";
            // httpWebRequest.Headers.Add("aftership-api-key:********fdbfd93980b8c5***");
            httpWebRequest.ContentType = "application/json";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {

                string postData = "{\"jobTitle\": \"" + Query.Purpose + "\","
                                    + "\"customerNumber\": " + Query.CustomerID + ","
                                    + "\"plannedStartdate\": \"" + Query.AppointmentDate + "\","
                                    + "\"plannedEnddate\": \"" + Query.AppointmentDate + "\""
                                    + "}";
                streamWriter.Write(postData);
                streamWriter.Flush();
                streamWriter.Close();

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    resultresponse = streamReader.ReadToEnd();
                    result = resultresponse;
                }

            }

            return result;
        }

        public List<int> GetJobhistory(string customernumber)
        {
            List<int> Joblist = new List<int>();

            string url = "http://customerservicsapi20170919111831.azurewebsites.net/api/job/Alljobs?customernumber=" + int.Parse(customernumber);
            HttpWebRequest webreq = (HttpWebRequest)WebRequest.Create(url);
            webreq.ContentType = "application/json";
            //webreq.Accept = "text/xml";
            webreq.Headers.Clear();
            webreq.Method = "GET";
            Encoding encode = Encoding.GetEncoding("utf-8");
            HttpWebResponse webres = null;
            webres = (HttpWebResponse)webreq.GetResponse();
            Stream reader = null;
            reader = webres.GetResponseStream();
            StreamReader sreader = new StreamReader(reader, encode, true);
            string resultresponse = sreader.ReadToEnd();

            Array rr = resultresponse.Replace("[", "").Replace("]", "").Split(',').ToArray();

            foreach (string r in rr)
            {
                Joblist.Add(int.Parse(r));
            }
            return Joblist;
        }

        public List<int> GetOpenJobs(string customernumber)
        {
            List<int> Joblist = new List<int>();

            string url = "http://customerservicsapi20170919111831.azurewebsites.net/api/job/getopenjobs?customernumber=" + int.Parse(customernumber);
            HttpWebRequest webreq = (HttpWebRequest)WebRequest.Create(url);
            webreq.ContentType = "application/json";
            //webreq.Accept = "text/xml";
            webreq.Headers.Clear();
            webreq.Method = "GET";
            Encoding encode = Encoding.GetEncoding("utf-8");
            HttpWebResponse webres = null;
            webres = (HttpWebResponse)webreq.GetResponse();
            Stream reader = null;
            reader = webres.GetResponseStream();
            StreamReader sreader = new StreamReader(reader, encode, true);
            string resultresponse = sreader.ReadToEnd();

            Array rr = resultresponse.Replace("[", "").Replace("]", "").Split(',').ToArray();

            foreach (string r in rr)
            {
                Joblist.Add(int.Parse(r));
            }
            return Joblist;
        }

        public List<Appointment> GetJobDetails(int CustomerId)
        {
            List<Appointment> AppList = new List<Appointment>();

            string url = "http://customerservicsapi20170919111831.azurewebsites.net/api/job/JobDetail?CustomerID=" + CustomerId;
            HttpWebRequest webreq = (HttpWebRequest)WebRequest.Create(url);
            webreq.ContentType = "application/json";
            //webreq.Accept = "text/xml";
            webreq.Headers.Clear();
            webreq.Method = "GET";
            Encoding encode = Encoding.GetEncoding("utf-8");
            HttpWebResponse webres = null;
            webres = (HttpWebResponse)webreq.GetResponse();
            Stream reader = null;
            reader = webres.GetResponseStream();
            StreamReader sreader = new StreamReader(reader, encode, true);
            string resultresponse = sreader.ReadToEnd();

            List<JobModel> Jobs = JsonConvert.DeserializeObject<List<JobModel>>(resultresponse);
            foreach(var job in Jobs)
            {
                Appointment App = new Appointment();
                App.AppointmentId = job.JobNumber.ToString();
                App.AppointmentDate = job.PlannedStartdate.ToString();
                App.Purpose = job.JobTitle;
                App.CustomerId = job.CustomerNumber.ToString();
                App.Status = job.JobStatus;
                AppList.Add(App);
            }
            return AppList;
        }

        public bool CancelAppointments(int Jobnumber)
        {
            bool response = false;

            string resultresponse = string.Empty;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://customerservicsapi20170919111831.azurewebsites.net/api/job/cancel");
            httpWebRequest.Method = "PUT";
            // httpWebRequest.Headers.Add("aftership-api-key:********fdbfd93980b8c5***");
            httpWebRequest.ContentType = "application/json";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {

                string postData = "{\"jobNumber\": " + Jobnumber + ""
                                    + "}";
                streamWriter.Write(postData);
                streamWriter.Flush();
                streamWriter.Close();

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    resultresponse = streamReader.ReadToEnd();
                    if (resultresponse == "true")
                        response = true;
                }

            }
            return response;
        }

        public bool RescheduleAppointments(AppointmentRescheduleQuery app)
        {
            bool response = false;

            string resultresponse = string.Empty;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://customerservicsapi20170919111831.azurewebsites.net/api/job/Reschedule");
            httpWebRequest.Method = "PUT";
            // httpWebRequest.Headers.Add("aftership-api-key:********fdbfd93980b8c5***");
            httpWebRequest.ContentType = "application/json";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string postData = "{\"jobNumber\": " + app.AppointmentID + ","
                                    + "\"plannedStartdate\": \"" + app.RescueduleDate + "\","
                                    + "\"plannedEnddate\": \"" + app.RescueduleDate + "\""
                                    + "}";

                streamWriter.Write(postData);
                streamWriter.Flush();
                streamWriter.Close();

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    resultresponse = streamReader.ReadToEnd();
                    if (resultresponse == "true")
                        response = true;
                }

            }
            return response;
        }
    }
}