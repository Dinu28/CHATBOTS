﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BotBuilder.Samples.AdaptiveCards.Models
{
    public class CustomerModel
    {
        public Guid ContactId { get; set; }

        public int ContactNumber { get; set; }
        public string EMailAddress1 { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Telephone1 { get; set; }

        public string Address1_Line1 { get; set; }
        public string Address1_Line2 { get; set; }
        public string Address1_City { get; set; }
        public string Address1_StateOrProvince { get; set; }
        public int Address1_PostalCode { get; set; }
        public string Address1_Country { get; set; }

        public string SecretQuestion { get; set; }

        public string SecretAnswer { get; set; }
    }
}