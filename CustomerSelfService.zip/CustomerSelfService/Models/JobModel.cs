﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BotBuilder.Samples.AdaptiveCards.Models
{
    public class JobModel
    {
        public Guid InstallationjobId { get; set; }

        public int JobNumber { get; set; }
        public string JobTitle { get; set; }

        public string JobCategory { get; set; }

        public int JobCategoryvalue { get; set; }

        public int CustomerNumber { get; set; }

        public string StoreName { get; set; }

        public string StoreAssociate { get; set; }

        public DateTime PlannedStartdate { get; set; }

        public DateTime PlannedEnddate { get; set; }

        public DateTime ActualStartDate { get; set; }
        public DateTime ActualEndDate { get; set; }

        public string Vendor { get; set; }

        public string Installer { get; set; }

        public string JobStatus { get; set; }

        public int JobStatusvalue { get; set; }
    }
}