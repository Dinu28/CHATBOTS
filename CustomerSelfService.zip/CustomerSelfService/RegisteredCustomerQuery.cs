﻿namespace BotBuilder.Samples.AdaptiveCards
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class RegisteredCustomerQuery
    {
        [Required]
        public string CustomerId { get; set; }
        

        public static RegisteredCustomerQuery Parse(dynamic o)
        {
            try
            {
                return new RegisteredCustomerQuery
                {
                    CustomerId = o.CustomerId.ToString()
                };
            }
            catch
            {
                throw new InvalidCastException("RegisteredCustomerQuery could not be read");
            }
        }
    }
}