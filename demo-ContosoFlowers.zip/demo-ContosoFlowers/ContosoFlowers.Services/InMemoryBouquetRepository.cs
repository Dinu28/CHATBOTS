﻿namespace ContosoFlowers.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using Models;

    public class InMemoryBouquetRepository : InMemoryRepositoryBase<Bouquet>
    {
        private IEnumerable<Bouquet> bouquets;

        public InMemoryBouquetRepository()
        {
            this.bouquets = Enumerable.Range(1, 10)
                .Select(i => new Bouquet
                {
                    Name = $"Product {i}\u2122",
                    ImageUrl = $"https://placeholdit.imgix.net/~text?txtsize=48&txt={HttpUtility.UrlEncode("Product " + i)}&w=620&h=320",
                    Price = new Random(i).Next(10, 66) + .99,
                    
                    // randomizing the flower category but ensuring at least 1 bouquet for each of it.
                    FlowerCategory = (i <= 3) ? $"Department {i}" : "Department " + new Random(i).Next(1, 3) 
                });
        }

        public override Bouquet GetByName(string name)
        {
            return this.bouquets.SingleOrDefault(x => x.Name.Equals(name, StringComparison.InvariantCultureIgnoreCase));
        }

        protected override IEnumerable<Bouquet> Find(Func<Bouquet, bool> predicate)
        {
            return predicate != default(Func<Bouquet, bool>) ? this.bouquets.Where(predicate) : this.bouquets;
        }
    }
}